# subscription-service-manager
chrome extensions of subscription service maneger

サブスクリプションサービスを管理するためのクロームの拡張機能のソースファイルです。
現時点でリリースはしていません。
